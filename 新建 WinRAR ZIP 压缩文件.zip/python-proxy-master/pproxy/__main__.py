if __name__ == '__main__':
    from .server import main
    main()
